﻿namespace RestuarantManagementSystemForm
{
    partial class Cook
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.FoodGridView = new System.Windows.Forms.DataGridView();
            this.deleteAccountBtn = new System.Windows.Forms.Button();
            this.updateAccountBtn = new System.Windows.Forms.Button();
            this.loadAccountBtn = new System.Windows.Forms.Button();
            this.insertAccountBtn = new System.Windows.Forms.Button();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.Search = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.FoodGridView)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // FoodGridView
            // 
            this.FoodGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.FoodGridView.Location = new System.Drawing.Point(317, 91);
            this.FoodGridView.Name = "FoodGridView";
            this.FoodGridView.ReadOnly = true;
            this.FoodGridView.Size = new System.Drawing.Size(374, 370);
            this.FoodGridView.TabIndex = 16;
            this.FoodGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.FoodGridView_CellContentClick);
            // 
            // deleteAccountBtn
            // 
            this.deleteAccountBtn.BackColor = System.Drawing.Color.FloralWhite;
            this.deleteAccountBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.deleteAccountBtn.ForeColor = System.Drawing.Color.Crimson;
            this.deleteAccountBtn.Location = new System.Drawing.Point(0, 212);
            this.deleteAccountBtn.Name = "deleteAccountBtn";
            this.deleteAccountBtn.Size = new System.Drawing.Size(129, 35);
            this.deleteAccountBtn.TabIndex = 15;
            this.deleteAccountBtn.Text = "Delete";
            this.deleteAccountBtn.UseVisualStyleBackColor = false;
            this.deleteAccountBtn.Click += new System.EventHandler(this.deleteAccountBtn_Click);
            // 
            // updateAccountBtn
            // 
            this.updateAccountBtn.BackColor = System.Drawing.Color.FloralWhite;
            this.updateAccountBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.updateAccountBtn.ForeColor = System.Drawing.Color.Crimson;
            this.updateAccountBtn.Location = new System.Drawing.Point(0, 155);
            this.updateAccountBtn.Name = "updateAccountBtn";
            this.updateAccountBtn.Size = new System.Drawing.Size(129, 35);
            this.updateAccountBtn.TabIndex = 14;
            this.updateAccountBtn.Text = "Update";
            this.updateAccountBtn.UseVisualStyleBackColor = false;
            this.updateAccountBtn.Click += new System.EventHandler(this.updateAccountBtn_Click);
            // 
            // loadAccountBtn
            // 
            this.loadAccountBtn.BackColor = System.Drawing.Color.Crimson;
            this.loadAccountBtn.ForeColor = System.Drawing.Color.Cornsilk;
            this.loadAccountBtn.Location = new System.Drawing.Point(317, 49);
            this.loadAccountBtn.Name = "loadAccountBtn";
            this.loadAccountBtn.Size = new System.Drawing.Size(119, 26);
            this.loadAccountBtn.TabIndex = 12;
            this.loadAccountBtn.Text = "Load";
            this.loadAccountBtn.UseVisualStyleBackColor = false;
            this.loadAccountBtn.Click += new System.EventHandler(this.loadAccountBtn_Click);
            // 
            // insertAccountBtn
            // 
            this.insertAccountBtn.BackColor = System.Drawing.Color.FloralWhite;
            this.insertAccountBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.insertAccountBtn.ForeColor = System.Drawing.Color.Crimson;
            this.insertAccountBtn.Location = new System.Drawing.Point(0, 99);
            this.insertAccountBtn.Name = "insertAccountBtn";
            this.insertAccountBtn.Size = new System.Drawing.Size(129, 35);
            this.insertAccountBtn.TabIndex = 13;
            this.insertAccountBtn.Text = "Insert";
            this.insertAccountBtn.UseVisualStyleBackColor = false;
            this.insertAccountBtn.Click += new System.EventHandler(this.insertAccountBtn_Click);
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(140, 288);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(116, 20);
            this.textBox4.TabIndex = 36;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(45, 291);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(64, 13);
            this.label5.TabIndex = 35;
            this.label5.Text = "FoodPrice";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(140, 242);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(116, 20);
            this.textBox2.TabIndex = 33;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(140, 195);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(116, 20);
            this.textBox1.TabIndex = 32;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(45, 245);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 13);
            this.label2.TabIndex = 30;
            this.label2.Text = "FoodName ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(45, 202);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(50, 13);
            this.label4.TabIndex = 29;
            this.label4.Text = "FoodId ";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBox5
            // 
            this.textBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox5.Location = new System.Drawing.Point(545, 49);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(146, 26);
            this.textBox5.TabIndex = 38;
            this.textBox5.TextChanged += new System.EventHandler(this.textBox5_TextChanged);
            // 
            // Search
            // 
            this.Search.BackColor = System.Drawing.Color.FloralWhite;
            this.Search.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Search.ForeColor = System.Drawing.Color.Crimson;
            this.Search.Location = new System.Drawing.Point(0, 20);
            this.Search.Name = "Search";
            this.Search.Size = new System.Drawing.Size(129, 27);
            this.Search.TabIndex = 37;
            this.Search.Text = "Search";
            this.Search.UseVisualStyleBackColor = false;
            this.Search.Click += new System.EventHandler(this.Search_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(0, 405);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(161, 41);
            this.button1.TabIndex = 39;
            this.button1.Text = "Log Out";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Crimson;
            this.panel1.Location = new System.Drawing.Point(2, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(997, 29);
            this.panel1.TabIndex = 40;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Crimson;
            this.panel2.Controls.Add(this.updateAccountBtn);
            this.panel2.Controls.Add(this.insertAccountBtn);
            this.panel2.Controls.Add(this.button1);
            this.panel2.Controls.Add(this.deleteAccountBtn);
            this.panel2.Controls.Add(this.Search);
            this.panel2.Location = new System.Drawing.Point(703, 30);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(164, 446);
            this.panel2.TabIndex = 41;
            // 
            // Cook
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(860, 473);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.FoodGridView);
            this.Controls.Add(this.loadAccountBtn);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "Cook";
            this.Text = "Cook";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.CloseApplication);
            ((System.ComponentModel.ISupportInitialize)(this.FoodGridView)).EndInit();
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.DataGridView FoodGridView;
        private System.Windows.Forms.Button deleteAccountBtn;
        private System.Windows.Forms.Button updateAccountBtn;
        private System.Windows.Forms.Button loadAccountBtn;
        private System.Windows.Forms.Button insertAccountBtn;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Button Search;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
    }
}