﻿CREATE TABLE [dbo].[FoodTable]
(
	[FoodId] INT NOT NULL PRIMARY KEY, 
    [FoodName] NCHAR(50) NOT NULL, 
    [FoodPrice] FLOAT NOT NULL 
)
